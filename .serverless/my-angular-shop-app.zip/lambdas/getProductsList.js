/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module) => {

const Responses = {
  _200(data = {}) {
    return {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Origin': '*',
      },
      statusCode: 200,
      body: JSON.stringify(data),
    }
  },
  _400(data = {}) {
    return {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Origin': '*',
      },
      statusCode: 400,
      body: JSON.stringify(data),
    }
  }
}

module.exports = Responses;

/***/ }),
/* 2 */
/***/ ((module) => {

const products = [
  {
    "id":"0a236bd7-3e0c-4419",
    "count":1,
    "description":"Nulla suscipit ligula in lacus. Curabitur at ipsum ac tellus semper interdum.",
    "price":64.09,
    "title":"Pellentesque viverra pede ac diam."
  },
  {
    "id":"4f8533e1-36f2-4453",
    "count":2,
    "description":"Duis ac nibh.",
    "price":99.34,
    "title":"Nullam varius."
  },
  {
    "id":"efd961fd-ec93-4c8e",
    "count":3,
    "description":"Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum.",
    "price":98.66,
    "title":"Etiam faucibus cursus urna."
  }
];

module.exports = products;

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;
const Responses = __webpack_require__(1);
const products = __webpack_require__(2);

const getProductsList = async() => {
  // For now it is just returning a list of mock data
  return products;
}

exports.handler = async(event) => {
  let response;
  try {
    const result = await getProductsList();
    response = Responses._200(result);
  } catch (error) {
    response = Responses._400({message: "Products not found!"});
  }
  return response;
};
})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;